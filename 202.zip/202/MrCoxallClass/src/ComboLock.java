/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2019-09-30
* Created for: ICS4U
* Daily Assignment: #2-02
* Pushes onto stack, then pops off stack
*
*******************************************************************************/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class ComboLock {

	public static void main(String[] args) throws IOException {
			
	        MrCoxallClass aStack = new MrCoxallClass();
	        String anItem;
			
	        InputStreamReader r = new InputStreamReader(System.in);
	        BufferedReader br = new BufferedReader(r);
	        
	        System.out.println("String for stack #1");
	        
	            anItem = br.readLine();
	            aStack.push(anItem);
	            
	        System.out.println("String for stack #2");
	        anItem = br.readLine();
	        aStack.push(anItem);
	        
	        System.out.println("Popping last push...");
	            aStack.pop(anItem);

	    }
		
	}


