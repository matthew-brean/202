/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2019-09-30
* Created for: ICS4U
* Daily Assignment: #2-02
* Stack class
*
*******************************************************************************/

import java.util.ArrayList;


public class MrCoxallClass {

    private ArrayList<String> _theStackList = new ArrayList<String>();
	
    public void push(String valueToPutOnStack) {
		
        _theStackList.add(valueToPutOnStack);
        System.out.println(_theStackList);
    }
    
    public void pop(String valueToPutOnStack) {
		
        _theStackList.remove(valueToPutOnStack);
        System.out.println(_theStackList);
    }
}